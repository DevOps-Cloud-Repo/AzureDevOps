# Azure Container Service

See https://docs.microsoft.com/en-us/azure/container-service/container-service-docker-swarm.