# Azure Container Instances

This template demonstrates a simple use case for [Azure Container Instances](https://docs.microsoft.com/en-us/azure/container-instances/).