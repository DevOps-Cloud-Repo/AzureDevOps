# Create Availability Set

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FAzure%2Fazure-quickstart-templates%2Fmaster%2F101-availability-set-create-3FDs-20UDs%2Fazuredeploy.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
<a href="http://armviz.io/#/?load=https%3A%2F%2Fraw.githubusercontent.com%2FAzure%2Fazure-quickstart-templates%2Fmaster%2F101-availability-set-create-3FDs-20UDs%2Fazuredeploy.json" target="_blank">
    <img src="http://armviz.io/visualizebutton.png"/>
</a>

This template creates an Availability Set and configures it for 3 Fault Domains and 20 Update Domains. This is just a snippet you may want to include in a more complex template 3 FDs are very useful when you're building a quorum-based solution or simply to ensure high availability of your service.
